import { Link } from "react-router-dom";
import {TbListDetails} from "react-icons/tb";
import { TbShoppingBagCheck } from "react-icons/tb";
import {MdDeleteOutline} from "react-icons/md";
import { productQuantity, shortenText } from "../helper/helper";
import styles from "./Card.module.css";

function Card({data}) {
    const {id, title , image, price}=data;

    const [state , dispatch] =useCart();
    const quantity = productQuantity(state , id)
    
    const clickHandler=(type)=>{
        dispatch({type:"add" , payload:data})

    }

    return (
    
     <div className={styles.card}>
        <img src={image} alt={title} />
        <h3>{shortenText(title)}</h3>
        <p>{price} $</p>
        <div className={styles.actions}>
            <link to={`/products/${id}`}><TbListDetails /> </link>
            <div>
                {
                    quantity ===1 && (
                        <button onklick={()=>clickHandler("REMOVE-ITEM")}><MdDeleteOutline /></button>
                    )
                }

                {
                    quantity >1 && (
                        <button onklick={()=>clickHandler("DECREASE")}>-</button>
                    )
                }

                {!!quantity &&<span>{quantity}</span>}

                {
                    quantity===0 ? (
                        <button onklick={()=>clickHandler("ADD-ITEM")}><TbShoppingBagCheck /></button>

                    ):(
                        <button onklick={()=>clickHandler("INCREASE")}>+</button>
                    )
                }
                
                


            </div>
        </div>
    
     <div/>)
    
    
};

export default Card;
