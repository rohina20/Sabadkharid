import { Link,useParams } from "react-router-dom"
import {SiOpenproject} from "react-icons/si";
import {IoMdPricetag} from "icons-react/io";
import {faArrowLeft} from "react-icons/fa";
import styles from "./DetailsPage.module.css";

import { useProductDetails } from "../context/ProductContext";
import Loader from "../components/Loader";

function DetailsPage() {
    const {id} = useParams();
    const productDetails = useProductDetails(+id)
    if (!productDetails) return <Loader />
    return (
        <div className={styles.container}>
            <img src={productDetails.image} alt={productDetails.title} />
            <div className={styles.information}>
                <h3 className={styles.title}>{productDetails.title}</h3>
                <p className={styles.description}>{productDetails.description}</p>
                <p className={styles.category}><SiOpenproject />
                {productDetails.category}
                </p>
                <div>
                    <span className={styles.price}>
                        <IoMdPricetag />
                        {productDetails.price}</span>
                    <link to="/products">
                        <faArrowLeft />
                        <span>Back to Shop</span></link>
                </div>
            </div>
        </div>
        
    )
}

export default DetailsPage
