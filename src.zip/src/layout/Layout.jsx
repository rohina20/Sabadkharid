import {link} from "react-router-dom";
import {PiShoppingCartSimpleBold} from "react-icons/pi";
import { useCart } from "../context/CartContext";
import styles from "./layout.module.css";

function Layout({children}) {
    const [state]= useCart();
    return (
        <>
         <header className={styles.header}>
            <link to="/products">Bestshop</link>
            <link to="/checkout">
                <div><PiShoppingCartSimpleBold />
                  {!!state.itemsCounter && <span>{state.itemsCounter}</span>}
                </div>
            </link>

         </header>
         {children}
         <footer className={styles.footer}>
            <p>Developed by Rohina</p>
         </footer>
        </>
    )
}

export default Layout
