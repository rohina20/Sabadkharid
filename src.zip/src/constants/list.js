const categories = [
    { id:1 ,type:"All" },
    { id:2 ,type:"Electronics" },
    { id:3 ,type:"jwelery" },
    { id:4 ,type:"men's clothing" },
    { id:5 ,type:"women's clothing" },

]

export {categories};